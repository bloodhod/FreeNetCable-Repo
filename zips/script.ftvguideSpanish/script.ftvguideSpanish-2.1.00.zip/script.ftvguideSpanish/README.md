script.ftvguideSpanish
===============

FTV Guide allows you to combine some of your favourite live TV plugins for use with a fully working EPG.

Based on the original TV Guide by twinther.

This repository is maintained by rayw1986 and bluezed and FreeNetCable.

For official support go to the forums on [tvaddons.ag](http://forums.tvaddons.ag/threads/22837-RELEASE-FTV-Guide)

**PLEASE NOTE:** 
This repository is used for development purposes only and may contain untested, experimental and unstable code. 
We recommend that you use the official release version instead which can always be found in the official 
[FTV-Guide-Repo](https://github.com/bloodhod/FTVGuide-Repo/blob/master/README.md)