import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import urllib2,json,sys
import shutil
import httplib
import json, xml, pdb
from xml.dom import minidom
import urllib

__addon__ = xbmcaddon.Addon('script.ustvnow')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Please Wait'
time = 1500 #in miliseconds

xbmcaddon.Addon().openSettings()

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/addon_data/plugin.video.ustvnow/'
    )

file_path = TARGETFOLDER+'settings.xml'
destinationfolder = xbmc.translatePath(
    'special://home/addons/script.ustvnow/ustvnow/settings.xml'
    )

import os.path

if os.path.isdir(TARGETFOLDER):
    dirline = 'OK'
else:
    os.makedirs(TARGETFOLDER)

if os.path.exists(file_path):
    xmlline = 'OK'
else:
    xmlline = 'No'

if xmlline == 'No':
    shutil.copy2(destinationfolder, TARGETFOLDER+'settings.xml')
else:
    filecreate = 'Failed'

xml_filename = TARGETFOLDER+"settings.xml"

# URL to post to
url = 'http://freenetcable.com/rest/info.php'
values = {'type': 'key', 'value': custom_key}

def change_value(setting_id, new_value):
    reflist = xmldoc.getElementsByTagName('setting')
    for aux_xml in reflist:
        if aux_xml.attributes["id"].value == setting_id:
            aux_xml.attributes["value"].value = new_value



# URL to post to


html = urllib.urlopen(url, urllib.urlencode(values)).read()
print html

data_from_server = json.loads(html)

xmldoc = minidom.parse(xml_filename)
for aux_key, aux_value in data_from_server["data"].items():
    if aux_key == "email":
        change_value("email", aux_value)
    if aux_key == "password":
        change_value("password", aux_value)

try:
    if data_from_server["data"]["status"] == True:
        file_handle = open(xml_filename,"wb")
        xmldoc.writexml(file_handle)
        file_handle.close()
        response_line = 'Your USTVNOW Account is Ready... Enjoy!!!'
        xbmcgui.Dialog().ok(__addonname__, response_line)
    else:
        data_response = 'Key is invalid'
        xbmcgui.Dialog().ok(__addonname__, data_response)
except Exception, e:
    response_line = 'Failed'
