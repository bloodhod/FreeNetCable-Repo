#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#
#      Modified for tecbox Guide (02/2015 onwards)
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#
import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import urllib2,json,sys
import shutil
import httplib
import json, xml, pdb
from xml.dom import minidom
import urllib


__addon__ = xbmcaddon.Addon('script.ipregister')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Please Wait'
line2 = 'Failed'
line3 = 'Activating FnCable'
line4 = line1+' '+line3
line5 = 'Activating USTVNOW and IPTV'
time = 3000 #in miliseconds

xbmcaddon.Addon().openSettings()

kb = xbmc.Keyboard('', 'Please enter some text')
if kb.isConfirmed():
    enteredvalue= kb.getText()
    xbmcgui.Dialog().ok(__addonname__, enteredvalue)

custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__, line4, time, __icon__))

url = "http://freenetcable.com/live/test/reg.php?key="+custom_key
print 'getting url...'
try:
    dic = json.loads(urllib2.urlopen(url).read())
    if dic['data'].has_key('registered_ip'):
        response_line1 = 'Successfully Activated Your FnCable'
        registerkeyvalue = "Registered"
    elif dic['data'].has_key('message'):
        response_line1 = dic['data']['message']
        registerkeyvalue = 'Failed'
    response_line2 = dic['data']['status']
    print response_line1
    print response_line2
except Exception as er:
    print str(er)
    print 'the data from the given url address is not json encoded'

if registerkeyvalue == 'Registered':
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__, line5, time, __icon__))
	getethmac = open('/sys/class/net/eth0/address').read()
	custom_key1 = getethmac.replace(':','')
	custom_key = custom_key1[:12]

	TARGETFOLDER = xbmc.translatePath(
	    'special://home/userdata/addon_data/plugin.video.stalker/'
	    )

	file_path = TARGETFOLDER+'settings.xml'
	destinationfolder = xbmc.translatePath(
	    'special://home/addons/script.ipregister/iptv/settings.xml'
	    )

	import os.path

	if os.path.isdir(TARGETFOLDER):
	    dirline = 'OK'
	else:
	    os.makedirs(TARGETFOLDER)

	if os.path.exists(file_path):
	    xmlline = 'OK'
	else:
	    xmlline = 'No'

	if xmlline == 'No':
	    shutil.copy2(destinationfolder, TARGETFOLDER+'settings.xml')
	else:
	    filecreate = 'Failed'

	xml_filename = TARGETFOLDER+"settings.xml"

	# URL to post to
	url = 'http://freenetcable.com/rest/info.php'
	values = {'type': 'mac', 'value': custom_key}

	def change_value(setting_id, new_value):
	    reflist = xmldoc.getElementsByTagName('setting')
	    for aux_xml in reflist:
	        if aux_xml.attributes["id"].value == setting_id:
	            aux_xml.attributes["value"].value = new_value



	html = urllib.urlopen(url, urllib.urlencode(values)).read()
	print html
	data_from_server = json.loads(html)

	xmldoc = minidom.parse(xml_filename)
	for aux_key, aux_value in data_from_server["data"].items():
	    if aux_key == "custom_mac_1":
	        change_value("custom_mac_1", aux_value)
	    if aux_key == "custom_serial_1":
	        change_value("custom_serial_1", aux_value)
	    if aux_key == "parental":
	        change_value("parental", aux_value)
	    if aux_key == "portal_mac_1":
	        change_value("portal_mac_1", aux_value)
	    if aux_key == "portal_name_1":
	        change_value("portal_name_1", aux_value)
	    if aux_key == "portal_url_1":
	        change_value("portal_url_1", aux_value)
	    if aux_key == "send_serial_1":
	        change_value("send_serial_1", aux_value)
	    if aux_key == "server_enable":
	        change_value("server_enable", aux_value)
	    if aux_key == "server_port":
	        change_value("server_port", aux_value)

	try:
	    if data_from_server["data"]["status"] == True:
	        file_handle = open(xml_filename,"wb")
	        xmldoc.writexml(file_handle)
	        file_handle.close()
	        response_line = 'Your IPTV Account is Ready... Enjoy!!!'
	    else:
	        data_response = 'Your Mac is invalid'
	        xbmcgui.Dialog().ok(__addonname__, data_response)
	except Exception, e:
	    response_line = 'Failed'

	TARGETFOLDER = xbmc.translatePath(
	    'special://home/userdata/addon_data/plugin.video.ustvnow/'
	    )

	file_path = TARGETFOLDER+'settings.xml'
	destinationfolder = xbmc.translatePath(
	    'special://home/addons/script.ipregister/ustvnow/settings.xml'
	    )

	custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

	import os.path

	if os.path.isdir(TARGETFOLDER):
	    dirline = 'OK'
	else:
	    os.makedirs(TARGETFOLDER)

	if os.path.exists(file_path):
	    xmlline = 'OK'
	else:
	    xmlline = 'No'

	if xmlline == 'No':
	    shutil.copy2(destinationfolder, TARGETFOLDER+'settings.xml')
	else:
	    filecreate = 'Failed'

	xml_filename = TARGETFOLDER+"settings.xml"

	# URL to post to
	url = 'http://freenetcable.com/rest/info.php'
	values = {'type': 'key', 'value': custom_key}

	def change_value(setting_id, new_value):
	    reflist = xmldoc.getElementsByTagName('setting')
	    for aux_xml in reflist:
	        if aux_xml.attributes["id"].value == setting_id:
	            aux_xml.attributes["value"].value = new_value



	# URL to post to


	html = urllib.urlopen(url, urllib.urlencode(values)).read()
	print html

	data_from_server = json.loads(html)

	xmldoc = minidom.parse(xml_filename)
	for aux_key, aux_value in data_from_server["data"].items():
	    if aux_key == "email":
	        change_value("email", aux_value)
	    if aux_key == "password":
	        change_value("password", aux_value)

	try:
	    if data_from_server["data"]["status"] == True:
	        file_handle = open(xml_filename,"wb")
	        xmldoc.writexml(file_handle)
	        file_handle.close()
	        response_line = 'Your USTVNOW Account is Ready... Enjoy!!!'
	    else:
	        data_response = 'Your Key is invalid'
	        xbmcgui.Dialog().ok(__addonname__, data_response)
	except Exception, e:
	    response_line = 'Failed'
else:
	itfailed = 'Failed'

xbmcgui.Dialog().ok(__addonname__, response_line1)