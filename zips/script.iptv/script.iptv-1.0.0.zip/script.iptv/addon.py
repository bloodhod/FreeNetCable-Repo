import time
import os
import xbmc
import xbmcgui
import xbmcaddon
import urllib2,json,sys
import shutil
import httplib
import json, xml, pdb
from xml.dom import minidom
import urllib

__addon__ = xbmcaddon.Addon('script.iptv')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Please Wait'
time = 1500 #in miliseconds

xbmcaddon.Addon().openSettings()

xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
#custom_key = xbmcaddon.Addon('script.ipregister').getSetting("ipkey")

getethmac = open('/sys/class/net/eth0/address').read()
custom_key1 = getethmac.replace(':','')
custom_key = custom_key1[:12]

TARGETFOLDER = xbmc.translatePath(
    'special://home/userdata/addon_data/plugin.video.stalker/'
    )

file_path = TARGETFOLDER+'settings.xml'
destinationfolder = xbmc.translatePath(
    'special://home/addons/script.iptv/iptv/settings.xml'
    )

import os.path

if os.path.isdir(TARGETFOLDER):
    dirline = 'OK'
else:
    os.makedirs(TARGETFOLDER)

if os.path.exists(file_path):
    xmlline = 'OK'
else:
    xmlline = 'No'

if xmlline == 'No':
    shutil.copy2(destinationfolder, TARGETFOLDER+'settings.xml')
else:
    filecreate = 'Failed'

xml_filename = TARGETFOLDER+"settings.xml"

# URL to post to
url = 'http://freenetcable.com/rest/info.php'
values = {'type': 'mac', 'value': custom_key}

def change_value(setting_id, new_value):
    reflist = xmldoc.getElementsByTagName('setting')
    for aux_xml in reflist:
        if aux_xml.attributes["id"].value == setting_id:
            aux_xml.attributes["value"].value = new_value



html = urllib.urlopen(url, urllib.urlencode(values)).read()
print html
data_from_server = json.loads(html)

xmldoc = minidom.parse(xml_filename)
for aux_key, aux_value in data_from_server["data"].items():
    if aux_key == "custom_mac_1":
        change_value("custom_mac_1", aux_value)
    if aux_key == "custom_serial_1":
        change_value("custom_serial_1", aux_value)
    if aux_key == "parental":
        change_value("parental", aux_value)
    if aux_key == "portal_mac_1":
        change_value("portal_mac_1", aux_value)
    if aux_key == "portal_name_1":
        change_value("portal_name_1", aux_value)
    if aux_key == "portal_url_1":
        change_value("portal_url_1", aux_value)
    if aux_key == "send_serial_1":
        change_value("send_serial_1", aux_value)
    if aux_key == "server_enable":
        change_value("server_enable", aux_value)
    if aux_key == "server_port":
        change_value("server_port", aux_value)

try:
    if data_from_server["data"]["status"] == True:
        file_handle = open(xml_filename,"wb")
        xmldoc.writexml(file_handle)
        file_handle.close()
        response_line = 'Your IPTV Account is Ready... Enjoy!!!'
        xbmcgui.Dialog().ok(__addonname__, response_line)
    else:
        data_response = 'Key is invalid'
        xbmcgui.Dialog().ok(__addonname__, data_response)
except Exception, e:
    response_line = 'Failed'
   

#print response_line
