#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#
#      Modified for tecbox Guide (02/2015 onwards)
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#
import time
import os
import xbmc
import xbmcgui
import xbmcaddon

import shutil


__addon__ = xbmcaddon.Addon('script.fncsettings')
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

line1 = 'Successfully Deleted'
line2 = 'Failed. Retry'
time = 5000 #in miliseconds

TARGETFOLDER = xbmc.translatePath(
    'special://home/cache'
    )

path = TARGETFOLDER

for root, dirs, files in os.walk(TARGETFOLDER):
    for f in files:
    	os.unlink(os.path.join(root, f))
    for d in dirs:
   	shutil.rmtree(os.path.join(root, d))

num_files = len([f for f in os.listdir(path)
                if os.path.isfile(os.path.join(path, f))])
				
if num_files == 0:
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
else:
	xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line2, time, __icon__))